/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  VNR VIPER — Threat Signature Database                      ║
 * ║  Built from the Suno Tracker Encyclopedia (71+ entries)     ║
 * ║  Voss Neural Research LLC — 2026                            ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

// ─── KNOWN TRACKER COOKIE SIGNATURES ───
// Each entry: { name: cookie_name, domain_pattern: regex, category, threat, company }
const COOKIE_SIGNATURES = [
    // SESSION REPLAY
    { name: '_clck', domain: '.clarity.ms', category: 'Session Replay', threat: 'CRITICAL', company: 'Microsoft Clarity' },
    { name: '_clsk', domain: '.clarity.ms', category: 'Session Replay', threat: 'CRITICAL', company: 'Microsoft Clarity' },
    { name: 'CLID', domain: '.clarity.ms', category: 'Session Replay', threat: 'CRITICAL', company: 'Microsoft Clarity' },
    { name: 'MR', domain: '.clarity.ms', category: 'Session Replay', threat: 'HIGH', company: 'Microsoft Clarity' },

    // META / FACEBOOK
    { name: '_fbp', domain: '.facebook.com', category: 'Ad Pixel', threat: 'HIGH', company: 'Meta / Facebook' },
    { name: '_fbc', domain: '.facebook.com', category: 'Ad Pixel', threat: 'HIGH', company: 'Meta / Facebook' },
    { name: 'fr', domain: '.facebook.com', category: 'Ad Pixel', threat: 'HIGH', company: 'Meta / Facebook' },

    // TIKTOK
    { name: '_ttp', domain: '.tiktok.com', category: 'Ad Pixel', threat: 'HIGH', company: 'TikTok / ByteDance' },
    { name: '_tt_enable_cookie', domain: '.tiktok.com', category: 'Ad Pixel', threat: 'MEDIUM', company: 'TikTok / ByteDance' },

    // SNAPCHAT
    { name: '_scid', domain: '.snapchat.com', category: 'Ad Pixel', threat: 'HIGH', company: 'Snapchat' },
    { name: 'sc_at', domain: '.snapchat.com', category: 'Ad Pixel', threat: 'HIGH', company: 'Snapchat' },

    // TWITTER / X
    { name: 'muc_ads', domain: '.t.co', category: 'Ad Pixel', threat: 'MEDIUM', company: 'Twitter / X' },
    { name: 'personalization_id', domain: '.twitter.com', category: 'Ad Pixel', threat: 'HIGH', company: 'Twitter / X' },

    // GOOGLE ADS & DOUBLECLICK
    { name: 'IDE', domain: '.doubleclick.net', category: 'Ad Exchange', threat: 'CRITICAL', company: 'Google DoubleClick' },
    { name: '__gads', domain: '.google.com', category: 'Ad Exchange', threat: 'HIGH', company: 'Google Ads' },
    { name: '__gpi', domain: '.google.com', category: 'Ad Exchange', threat: 'HIGH', company: 'Google Ads' },
    { name: '_gcl_au', domain: '.google.com', category: 'Conversion', threat: 'HIGH', company: 'Google Conversion Linker' },
    { name: 'NID', domain: '.google.com', category: 'Tracking', threat: 'MEDIUM', company: 'Google' },

    // APPLOVIN
    { name: 'APPLOVIN_SDK', domain: '.applovin.com', category: 'Mobile Ads', threat: 'MEDIUM', company: 'AppLovin' },

    // AD EXCHANGE COOKIE SYNCING (the 42 domains)
    { name: 'uuid2', domain: '.adnxs.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Xandr (Microsoft)' },
    { name: 'TDID', domain: '.adsrvr.org', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'The Trade Desk' },
    { name: 'TDCPM', domain: '.adsrvr.org', category: 'Ad Exchange Sync', threat: 'MEDIUM', company: 'The Trade Desk' },
    { name: 'A3', domain: '.agkn.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Acxiom (Offline Linking)' },
    { name: 'bku', domain: '.bluekai.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Oracle BlueKai' },
    { name: 'CMPS', domain: '.casalemedia.com', category: 'Ad Exchange Sync', threat: 'MEDIUM', company: 'Casale Media' },
    { name: 'uid', domain: '.criteo.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Criteo (Retargeting)' },
    { name: 'cto_bundle', domain: '.criteo.com', category: 'Ad Exchange Sync', threat: 'MEDIUM', company: 'Criteo' },
    { name: 'CWcid', domain: '.crwdcntrl.net', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Lotame DMP' },
    { name: 'demdex', domain: '.demdex.net', category: 'Ad Exchange Sync', threat: 'CRITICAL', company: 'Adobe Audience Manager' },
    { name: 'dpm', domain: '.demdex.net', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Adobe' },
    { name: 'DSID', domain: '.doubleclick.net', category: 'Ad Exchange Sync', threat: 'CRITICAL', company: 'Google' },
    { name: 'FLC', domain: '.doubleclick.net', category: 'Ad Exchange Sync', threat: 'MEDIUM', company: 'Google' },
    { name: 'everest_g_v2', domain: '.everesttech.net', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Adobe Ad Cloud' },
    { name: 'EE', domain: '.exelator.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Nielsen eXelate' },
    { name: 'ID5', domain: '.id5-sync.com', category: 'Ad Exchange Sync', threat: 'CRITICAL', company: 'ID5 (Universal ID)' },
    { name: 'id5id', domain: '.id5-sync.com', category: 'Ad Exchange Sync', threat: 'CRITICAL', company: 'ID5' },
    { name: 'KRTBCOOKIE', domain: '.pubmatic.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'PubMatic' },
    { name: 'lidid', domain: '.liadm.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'LiveIntent (Email ID)' },
    { name: 'li_sugr', domain: '.linkedin.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'LinkedIn' },
    { name: 'rlas3', domain: '.rlcdn.com', category: 'Ad Exchange Sync', threat: 'CRITICAL', company: 'LiveRamp' },
    { name: 'pxrc', domain: '.rlcdn.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'LiveRamp' },
    { name: 'mc', domain: '.quantserve.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Quantcast' },
    { name: 'rpx', domain: '.rubiconproject.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Magnite (Rubicon)' },
    { name: 'khaos', domain: '.rubiconproject.com', category: 'Ad Exchange Sync', threat: 'MEDIUM', company: 'Magnite' },
    { name: 'tuuid', domain: '.bidswitch.net', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'BidSwitch (IPONWEB)' },
    { name: 't_gid', domain: '.taboola.com', category: 'Ad Exchange Sync', threat: 'MEDIUM', company: 'Taboola' },
    { name: 'TapAd_TS', domain: '.tapad.com', category: 'Cross-Device', threat: 'CRITICAL', company: 'Tapad (Experian)' },
    { name: 'TapAd_DID', domain: '.tapad.com', category: 'Cross-Device', threat: 'CRITICAL', company: 'Tapad (Experian)' },
    { name: 'MUID', domain: '.bing.com', category: 'Ad Exchange Sync', threat: 'HIGH', company: 'Microsoft Ads' },

    // OBFUSCATED / UNKNOWN
    { name: 'trk', domain: '.imtwjwoasak.com', category: 'Obfuscated', threat: 'CRITICAL', company: 'UNKNOWN — Stealth Tracker' },

    // SINGULAR (ATTRIBUTION)
    { name: 'singular_device_id', domain: '.singular.net', category: 'Attribution', threat: 'HIGH', company: 'Singular' },

    // BRAZE
    { name: 'ab.storage', domain: '.braze.com', category: 'Marketing', threat: 'HIGH', company: 'Braze' },
];

// ─── KNOWN TRACKER DOMAINS (for network-level detection) ───
const TRACKER_DOMAINS = [
    // Session Replay
    'scripts.clarity.ms', 'c.clarity.ms', 'clarity.ms',
    'snippet.maze.co', 'prompts.maze.co',

    // Marketing
    'sdk.iad-07.braze.com', 'sdk.iad-06.braze.com',
    's.axon.ai', 'sdk-api-v1.singular.net',
    'collector.agentio.com', 'static.agentio.com',

    // Ad Pixels
    'connect.facebook.net', 'www.facebook.com',
    'analytics.tiktok.com',
    'tr.snapchat.com', 'tr6.snapchat.com',
    'analytics.twitter.com', 't.co',
    'googleads.g.doubleclick.net', 'www.googletagmanager.com',
    'www.google-analytics.com', 'pagead2.googlesyndication.com',
    'res4.applovin.com', 're.applovin.com', 'b.applovin.com',

    // Analytics & Experimentation
    'featuregates.org', 'statsigapi.net', // Statsig
    'cdn.amplitude.com', 'api.amplitude.com',
    'api.segment.io', 'cdn.segment.com',

    // Identity Resolution
    'pixel.tapad.com',
    'imtwjwoasak.com',
    'pippio.com',

    // hCaptcha (Crypto PoW)
    'newassets.hcaptcha.com', 'imgs.hcaptcha.com',
    'accounts.hcaptcha.com', 'hcaptcha.com',

    // Ad Exchange Syncing
    'adnxs.com', 'adsrvr.org', 'agkn.com', 'bidswitch.net',
    'bluekai.com', 'casalemedia.com', 'criteo.com',
    'crwdcntrl.net', 'demdex.net', 'doubleclick.net',
    'everesttech.net', 'exelator.com', 'id5-sync.com',
    'liadm.com', 'mathtag.com', 'mookie1.com',
    'openx.net', 'pippio.com', 'pubmatic.com',
    'quantserve.com', 'rfihub.com', 'rlcdn.com',
    'rubiconproject.com', 'scorecardresearch.com',
    'semasio.net', 'sharethrough.com', 'simpli.fi',
    'ssp.yahoo.com', 'spotxchange.com', 'taboola.com',
    'tapad.com', 'tribalfusion.com', 'turn.com',
    'w55c.net', 'yahoo.com',
];

// ─── LOCALSTORAGE SIGNATURES (hCaptcha crypto PoW) ───
const LOCALSTORAGE_SIGNATURES = [
    { key: 'hcaptcha', description: 'hCaptcha base data', threat: 'HIGH', category: 'Crypto PoW' },
    { key: 'chainId', description: 'Blockchain chain identifier (0x1 = Ethereum)', threat: 'CRITICAL', category: 'Crypto PoW' },
    { key: '0x1', description: 'Ethereum mainnet reference', threat: 'CRITICAL', category: 'Crypto PoW' },
    { key: 'binance', description: 'Binance blockchain reference', threat: 'CRITICAL', category: 'Crypto PoW' },
    { key: 'logLevel', description: 'Logging suppression (SILENT = hidden)', threat: 'HIGH', category: 'Crypto PoW' },
    { key: 'braze', description: 'Braze marketing SDK data', threat: 'HIGH', category: 'Marketing' },
    { key: 'ab.storage', description: 'Braze persistent storage', threat: 'HIGH', category: 'Marketing' },
    { key: 'statsig', description: 'Statsig A/B experiment enrollment', threat: 'HIGH', category: 'Experimentation' },
    { key: 'amplitude', description: 'Amplitude analytics data', threat: 'MEDIUM', category: 'Analytics' },
    { key: 'segment', description: 'Segment analytics pipeline', threat: 'MEDIUM', category: 'Analytics' },
    { key: 'singular', description: 'Singular attribution data', threat: 'MEDIUM', category: 'Attribution' },
    { key: 'clarity', description: 'Microsoft Clarity session data', threat: 'CRITICAL', category: 'Session Replay' },
    { key: '_hjSession', description: 'Hotjar session replay', threat: 'HIGH', category: 'Session Replay' },
    { key: 'FullStory', description: 'FullStory session replay', threat: 'HIGH', category: 'Session Replay' },
    { key: 'intercom', description: 'Intercom tracking data', threat: 'MEDIUM', category: 'Marketing' },
];

// ─── INDEXEDDB DATABASE NAMES ───
const INDEXEDDB_SIGNATURES = [
    { name: 'braze', description: 'Braze marketing automation DB', threat: 'HIGH', category: 'Marketing' },
    { name: 'statsig', description: 'Statsig experiment store', threat: 'HIGH', category: 'Experimentation' },
    { name: 'amplitude', description: 'Amplitude event queue', threat: 'MEDIUM', category: 'Analytics' },
    { name: 'firebaseLocalStorage', description: 'Firebase persistence', threat: 'MEDIUM', category: 'Analytics' },
    { name: 'sentry', description: 'Sentry error tracking', threat: 'LOW', category: 'Telemetry' },
];

// Export for use in other modules
if (typeof module !== 'undefined') {
    module.exports = { COOKIE_SIGNATURES, TRACKER_DOMAINS, LOCALSTORAGE_SIGNATURES, INDEXEDDB_SIGNATURES };
}
