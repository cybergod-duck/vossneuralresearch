/**
 * VNR VIPER — Content Script
 * Runs on every page to detect active tracker scripts
 */

(function () {
    'use strict';

    // Known tracker script patterns
    const TRACKER_SCRIPT_PATTERNS = [
        { pattern: /clarity\.ms/i, name: 'Microsoft Clarity', threat: 'CRITICAL' },
        { pattern: /connect\.facebook\.net/i, name: 'Facebook Pixel', threat: 'HIGH' },
        { pattern: /analytics\.tiktok\.com/i, name: 'TikTok Pixel', threat: 'HIGH' },
        { pattern: /googletagmanager\.com/i, name: 'Google Tag Manager', threat: 'MEDIUM' },
        { pattern: /google-analytics\.com/i, name: 'Google Analytics', threat: 'MEDIUM' },
        { pattern: /doubleclick\.net/i, name: 'DoubleClick', threat: 'HIGH' },
        { pattern: /snap\.licdn\.com/i, name: 'LinkedIn Insight', threat: 'MEDIUM' },
        { pattern: /tr\.snapchat\.com/i, name: 'Snapchat Pixel', threat: 'HIGH' },
        { pattern: /analytics\.twitter\.com/i, name: 'Twitter/X Pixel', threat: 'MEDIUM' },
        { pattern: /hcaptcha\.com/i, name: 'hCaptcha (Crypto PoW)', threat: 'CRITICAL' },
        { pattern: /braze\.com/i, name: 'Braze SDK', threat: 'HIGH' },
        { pattern: /amplitude\.com/i, name: 'Amplitude', threat: 'MEDIUM' },
        { pattern: /segment\.(io|com)/i, name: 'Segment', threat: 'MEDIUM' },
        { pattern: /statsig/i, name: 'Statsig', threat: 'HIGH' },
        { pattern: /maze\.co/i, name: 'Maze', threat: 'MEDIUM' },
        { pattern: /applovin\.com/i, name: 'AppLovin', threat: 'HIGH' },
        { pattern: /singular\.net/i, name: 'Singular', threat: 'MEDIUM' },
        { pattern: /agentio\.com/i, name: 'Agentio', threat: 'LOW' },
        { pattern: /tapad\.com/i, name: 'Tapad (Experian)', threat: 'CRITICAL' },
        { pattern: /hotjar\.com/i, name: 'Hotjar', threat: 'HIGH' },
        { pattern: /fullstory\.com/i, name: 'FullStory', threat: 'HIGH' },
        { pattern: /intercom/i, name: 'Intercom', threat: 'MEDIUM' },
        { pattern: /criteo\.com/i, name: 'Criteo', threat: 'HIGH' },
        { pattern: /demdex\.net/i, name: 'Adobe Audience Manager', threat: 'HIGH' },
    ];

    let detectedCount = 0;

    // Scan all script tags on the page
    function scanPageScripts() {
        const scripts = document.querySelectorAll('script[src]');
        const detected = [];

        scripts.forEach(script => {
            const src = script.src || '';
            for (const tracker of TRACKER_SCRIPT_PATTERNS) {
                if (tracker.pattern.test(src)) {
                    detected.push({
                        name: tracker.name,
                        src: src,
                        threat: tracker.threat,
                    });
                    break;
                }
            }
        });

        if (detected.length > 0 && detected.length !== detectedCount) {
            detectedCount = detected.length;
            try {
                chrome.runtime.sendMessage({
                    type: 'TRACKER_DETECTED',
                    count: detected.length,
                    trackers: detected,
                    url: window.location.href,
                });
            } catch (e) {
                // Extension context may not be available
            }
        }

        return detected;
    }

    // Watch for dynamically injected scripts
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.tagName === 'SCRIPT' && node.src) {
                    for (const tracker of TRACKER_SCRIPT_PATTERNS) {
                        if (tracker.pattern.test(node.src)) {
                            detectedCount++;
                            try {
                                chrome.runtime.sendMessage({
                                    type: 'TRACKER_DETECTED',
                                    count: 1,
                                    trackers: [{ name: tracker.name, src: node.src, threat: tracker.threat }],
                                    url: window.location.href,
                                    dynamic: true,
                                });
                            } catch (e) { }
                            break;
                        }
                    }
                }
            }
        }
    });

    // Initial scan
    if (document.readyState === 'complete') {
        scanPageScripts();
    } else {
        window.addEventListener('load', scanPageScripts);
    }

    // Watch for dynamic script injection
    observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
    });
})();
