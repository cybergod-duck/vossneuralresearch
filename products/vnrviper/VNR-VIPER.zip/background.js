/**
 * VNR VIPER — Background Service Worker
 * Handles badge updates and tracker domain monitoring
 */

// Update badge when extension is installed
chrome.runtime.onInstalled.addListener(() => {
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    chrome.action.setBadgeText({ text: '' });
    console.log('[VNR VIPER] Extension installed — v1.0.0');
});

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'TRACKER_DETECTED') {
        // Update badge with threat count
        chrome.action.getBadgeText({}, (currentText) => {
            const current = parseInt(currentText) || 0;
            const newCount = current + (message.count || 1);
            chrome.action.setBadgeText({ text: String(newCount) });
            chrome.action.setBadgeBackgroundColor({
                color: newCount > 10 ? '#ef4444' : newCount > 3 ? '#f97316' : '#eab308'
            });
        });
        sendResponse({ status: 'ok' });
    }

    if (message.type === 'GET_SCAN_RESULTS') {
        // Return cached scan results if available
        chrome.storage.local.get('lastScan', (data) => {
            sendResponse(data.lastScan || null);
        });
        return true; // async response
    }

    if (message.type === 'SAVE_SCAN_RESULTS') {
        chrome.storage.local.set({
            lastScan: {
                ...message.results,
                timestamp: Date.now(),
            }
        });
        sendResponse({ status: 'saved' });
    }
});
