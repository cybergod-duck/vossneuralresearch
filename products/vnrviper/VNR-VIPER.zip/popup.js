/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  VNR VIPER — Popup Scanner Logic                            ║
 * ║  Scans cookies, localStorage, IndexedDB for tracker residue ║
 * ║  Voss Neural Research LLC — 2026                            ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

// ─── DOM REFS ───
const scanSection = document.getElementById('scanSection');
const scanningSection = document.getElementById('scanningSection');
const resultsSection = document.getElementById('resultsSection');
const scanBtn = document.getElementById('scanBtn');
const scanPercent = document.getElementById('scanPercent');
const scanningText = document.getElementById('scanningText');
const threatBar = document.getElementById('threatBar');
const threatScore = document.getElementById('threatScore');
const threatLabel = document.getElementById('threatLabel');
const cookieCount = document.getElementById('cookieCount');
const cryptoStatus = document.getElementById('cryptoStatus');
const replayStatus = document.getElementById('replayStatus');
const adSyncCount = document.getElementById('adSyncCount');
const findingsList = document.getElementById('findingsList');
const findingsCount = document.getElementById('findingsCount');
const cleanBtn = document.getElementById('cleanBtn');
const exportBtn = document.getElementById('exportBtn');
const rescanBtn = document.getElementById('rescanBtn');
const statusIndicator = document.getElementById('statusIndicator');

// ─── STATE ───
let scanResults = {
    cookies: [],
    localStorage: [],
    indexedDB: [],
    domains: [],
    totalThreats: 0,
    score: 0,
    cryptoDetected: false,
    replayDetected: false,
    adSyncDomains: 0,
};

// ─── SCAN PHASES ───
const SCAN_PHASES = [
    { text: 'Scanning cookies...', weight: 30 },
    { text: 'Checking localStorage for crypto PoW...', weight: 20 },
    { text: 'Scanning IndexedDB databases...', weight: 15 },
    { text: 'Detecting session replay hooks...', weight: 15 },
    { text: 'Mapping ad exchange syncs...', weight: 10 },
    { text: 'Calculating threat score...', weight: 10 },
];

// ─── PRO STATE ───
let isPro = false;
const proUpsell = document.getElementById('proUpsell');
const proActiveBadge = document.getElementById('proActiveBadge');
const licenseInput = document.getElementById('licenseInput');
const activateBtn = document.getElementById('activateBtn');

// Check stored license on load
chrome.storage.local.get('viperLicense', (data) => {
    if (data.viperLicense) {
        activatePro(data.viperLicense, false);
    }
});

function activatePro(key, save = true) {
    isPro = true;
    if (save) {
        chrome.storage.local.set({ viperLicense: key });
    }
    // Update UI
    proUpsell.classList.add('hidden');
    proActiveBadge.classList.remove('hidden');
    cleanBtn.innerHTML = '<span>🔥</span> BURN TRACKERS';
}

// ─── EVENT LISTENERS ───
scanBtn.addEventListener('click', startScan);
rescanBtn.addEventListener('click', () => {
    resultsSection.classList.add('hidden');
    scanSection.classList.remove('hidden');
    startScan();
});

cleanBtn.addEventListener('click', () => {
    if (isPro) {
        burnTrackers();
    } else {
        // Open Gumroad subscribe page
        chrome.tabs.create({ url: 'https://vossneuralresearch.gumroad.com/l/vnrviper' });
    }
});
exportBtn.addEventListener('click', exportReport);

activateBtn.addEventListener('click', async () => {
    const key = licenseInput.value.trim();
    if (key.length < 4) {
        licenseInput.style.borderColor = '#ef4444';
        setTimeout(() => { licenseInput.style.borderColor = ''; }, 1500);
        return;
    }

    // Show loading state
    activateBtn.textContent = 'Verifying...';
    activateBtn.disabled = true;

    try {
        const response = await fetch('https://api.gumroad.com/v2/licenses/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `product_id=vnrviper&license_key=${encodeURIComponent(key)}&increment_uses_count=true`
        });
        const data = await response.json();

        if (data.success) {
            licenseInput.style.borderColor = '#22c55e';
            activatePro(key);
        } else {
            licenseInput.style.borderColor = '#ef4444';
            licenseInput.style.animation = 'shake 0.3s';
            setTimeout(() => {
                licenseInput.style.borderColor = '';
                licenseInput.style.animation = '';
            }, 1500);
        }
    } catch (err) {
        // Offline fallback — accept key if it looks like a Gumroad key format
        if (key.length >= 8 && key.includes('-')) {
            activatePro(key);
        } else {
            licenseInput.style.borderColor = '#ef4444';
            setTimeout(() => { licenseInput.style.borderColor = ''; }, 1500);
        }
    }

    activateBtn.textContent = 'ACTIVATE';
    activateBtn.disabled = false;
});

licenseInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') activateBtn.click();
});

// ─── MAIN SCAN ───
async function startScan() {
    // Reset
    scanResults = {
        cookies: [], localStorage: [], indexedDB: [], domains: [],
        totalThreats: 0, score: 0, cryptoDetected: false, replayDetected: false, adSyncDomains: 0,
    };

    // Show scanning UI
    scanSection.classList.add('hidden');
    scanningSection.classList.remove('hidden');
    resultsSection.classList.add('hidden');

    updateStatus('SCANNING', '#eab308');

    // Phase 1: Scan cookies (30%)
    await animatePhase(0);
    await scanCookies();

    // Phase 2: Check localStorage (50%)
    await animatePhase(1);
    await scanLocalStorage();

    // Phase 3: IndexedDB (65%)
    await animatePhase(2);
    await scanIndexedDB();

    // Phase 4: Session replay (80%)
    await animatePhase(3);
    detectSessionReplay();

    // Phase 5: Ad exchange (90%)
    await animatePhase(4);
    countAdSyncs();

    // Phase 6: Calculate (100%)
    await animatePhase(5);
    calculateThreatScore();

    // Show results
    await sleep(500);
    scanningSection.classList.add('hidden');
    resultsSection.classList.remove('hidden');
    renderResults();
}

async function animatePhase(phaseIndex) {
    const phase = SCAN_PHASES[phaseIndex];
    scanningText.textContent = phase.text;

    let startPct = 0;
    for (let i = 0; i < phaseIndex; i++) startPct += SCAN_PHASES[i].weight;
    const endPct = startPct + phase.weight;

    for (let p = startPct; p <= endPct; p += 2) {
        scanPercent.textContent = `${Math.min(p, 100)}%`;
        await sleep(30 + Math.random() * 40);
    }
}

// ─── COOKIE SCANNER ───
async function scanCookies() {
    try {
        const allCookies = await chrome.cookies.getAll({});

        for (const cookie of allCookies) {
            for (const sig of COOKIE_SIGNATURES) {
                // Match by cookie name (case-insensitive partial match)
                if (cookie.name.toLowerCase().includes(sig.name.toLowerCase())) {
                    scanResults.cookies.push({
                        name: cookie.name,
                        domain: cookie.domain,
                        signature: sig,
                        value_length: cookie.value.length,
                        expires: cookie.expirationDate
                            ? new Date(cookie.expirationDate * 1000).toLocaleDateString()
                            : 'Session',
                    });
                    break;
                }
            }

            // Check domain against tracker domains
            for (const domain of TRACKER_DOMAINS) {
                if (cookie.domain.includes(domain)) {
                    if (!scanResults.domains.includes(domain)) {
                        scanResults.domains.push(domain);
                    }
                    break;
                }
            }
        }
    } catch (err) {
        console.log('Cookie scan limited:', err.message);
    }
}

// ─── LOCALSTORAGE SCANNER ───
async function scanLocalStorage() {
    try {
        // Query the active tab for localStorage data
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.id) return;

        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: scanLocalStorageInPage,
            args: [LOCALSTORAGE_SIGNATURES.map(s => s.key)],
        });

        if (results && results[0] && results[0].result) {
            const found = results[0].result;
            for (const item of found) {
                const sig = LOCALSTORAGE_SIGNATURES.find(
                    s => item.key.toLowerCase().includes(s.key.toLowerCase())
                );
                if (sig) {
                    scanResults.localStorage.push({
                        key: item.key,
                        size: item.size,
                        signature: sig,
                        preview: item.preview,
                    });

                    if (sig.category === 'Crypto PoW') {
                        scanResults.cryptoDetected = true;
                    }
                }
            }
        }
    } catch (err) {
        console.log('localStorage scan limited:', err.message);
    }
}

// Injected into the page
function scanLocalStorageInPage(signatureKeys) {
    const results = [];
    try {
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            for (const sigKey of signatureKeys) {
                if (key.toLowerCase().includes(sigKey.toLowerCase())) {
                    const val = localStorage.getItem(key) || '';
                    results.push({
                        key: key,
                        size: val.length,
                        preview: val.substring(0, 100),
                    });
                    break;
                }
            }
        }
    } catch (e) { }
    return results;
}

// ─── INDEXEDDB SCANNER ───
async function scanIndexedDB() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.id) return;

        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: scanIndexedDBInPage,
            args: [INDEXEDDB_SIGNATURES.map(s => s.name)],
        });

        if (results && results[0] && results[0].result) {
            for (const dbName of results[0].result) {
                const sig = INDEXEDDB_SIGNATURES.find(
                    s => dbName.toLowerCase().includes(s.name.toLowerCase())
                );
                if (sig) {
                    scanResults.indexedDB.push({ name: dbName, signature: sig });
                }
            }
        }
    } catch (err) {
        console.log('IndexedDB scan limited:', err.message);
    }
}

function scanIndexedDBInPage(signatureNames) {
    return new Promise((resolve) => {
        try {
            const found = [];
            if (indexedDB.databases) {
                indexedDB.databases().then(dbs => {
                    for (const db of dbs) {
                        for (const sigName of signatureNames) {
                            if (db.name && db.name.toLowerCase().includes(sigName.toLowerCase())) {
                                found.push(db.name);
                                break;
                            }
                        }
                    }
                    resolve(found);
                }).catch(() => resolve(found));
            } else {
                resolve(found);
            }
        } catch (e) {
            resolve([]);
        }
    });
}

// ─── SESSION REPLAY DETECTION ───
function detectSessionReplay() {
    const replayCookies = scanResults.cookies.filter(
        c => c.signature.category === 'Session Replay'
    );
    const replayLS = scanResults.localStorage.filter(
        l => l.signature.category === 'Session Replay'
    );
    scanResults.replayDetected = replayCookies.length > 0 || replayLS.length > 0;
}

// ─── AD SYNC COUNTER ───
function countAdSyncs() {
    const adSyncCookies = scanResults.cookies.filter(
        c => c.signature.category === 'Ad Exchange Sync' || c.signature.category === 'Cross-Device'
    );
    // Count unique companies
    const companies = new Set(adSyncCookies.map(c => c.signature.company));
    scanResults.adSyncDomains = companies.size;
}

// ─── THREAT SCORE CALCULATOR ───
function calculateThreatScore() {
    let score = 0;
    const maxScore = 100;

    // Cookie threats (max 40 points)
    const critCookies = scanResults.cookies.filter(c => c.signature.threat === 'CRITICAL').length;
    const highCookies = scanResults.cookies.filter(c => c.signature.threat === 'HIGH').length;
    const medCookies = scanResults.cookies.filter(c => c.signature.threat === 'MEDIUM').length;
    score += Math.min(critCookies * 5, 20);
    score += Math.min(highCookies * 3, 12);
    score += Math.min(medCookies * 1, 8);

    // Crypto PoW (20 points)
    if (scanResults.cryptoDetected) score += 20;

    // Session replay (15 points)
    if (scanResults.replayDetected) score += 15;

    // Ad exchange syncs (max 15 points)
    score += Math.min(scanResults.adSyncDomains * 2, 15);

    // IndexedDB (max 10 points)
    score += Math.min(scanResults.indexedDB.length * 3, 10);

    // Domain count bonus
    score += Math.min(scanResults.domains.length, 10);

    scanResults.score = Math.min(score, maxScore);
    scanResults.totalThreats = scanResults.cookies.length +
        scanResults.localStorage.length + scanResults.indexedDB.length;
}

// ─── RENDER RESULTS ───
function renderResults() {
    const score = scanResults.score;

    // Threat bar
    setTimeout(() => {
        threatBar.style.width = `${score}%`;
        if (score < 20) threatBar.className = 'threat-bar low';
        else if (score < 45) threatBar.className = 'threat-bar medium';
        else if (score < 70) threatBar.className = 'threat-bar high';
        else threatBar.className = 'threat-bar critical';
    }, 100);

    // Score text
    threatScore.textContent = `${score}%`;

    // Label
    if (score < 10) {
        threatLabel.textContent = '🟢 CLEAN';
        threatLabel.className = 'threat-label clean';
        updateStatus('CLEAN', '#22c55e');
    } else if (score < 30) {
        threatLabel.textContent = '🟡 LOW RISK';
        threatLabel.className = 'threat-label low';
        updateStatus('LOW RISK', '#eab308');
    } else if (score < 55) {
        threatLabel.textContent = '🟠 MODERATE';
        threatLabel.className = 'threat-label medium';
        updateStatus('MODERATE', '#f97316');
    } else if (score < 75) {
        threatLabel.textContent = '🔴 HIGH RISK';
        threatLabel.className = 'threat-label high';
        updateStatus('THREATS', '#ef4444');
    } else {
        threatLabel.textContent = '🔴 CRITICAL';
        threatLabel.className = 'threat-label critical';
        updateStatus('CRITICAL', '#ef4444');
    }

    // Stats
    cookieCount.textContent = scanResults.cookies.length;
    cryptoStatus.textContent = scanResults.cryptoDetected ? 'FOUND' : 'CLEAR';
    replayStatus.textContent = scanResults.replayDetected ? 'FOUND' : 'CLEAR';
    adSyncCount.textContent = scanResults.adSyncDomains;

    // Color code stat cards
    if (scanResults.cookies.length > 10) document.getElementById('cookieCard').classList.add('danger');
    else if (scanResults.cookies.length > 3) document.getElementById('cookieCard').classList.add('warning');

    if (scanResults.cryptoDetected) document.getElementById('cryptoCard').classList.add('danger');
    if (scanResults.replayDetected) document.getElementById('replayCard').classList.add('danger');
    if (scanResults.adSyncDomains > 5) document.getElementById('adSyncCard').classList.add('danger');

    // Findings list
    findingsList.innerHTML = '';
    const allFindings = [
        ...scanResults.cookies.map(c => ({
            name: c.signature.company,
            detail: `${c.name} @ ${c.domain}`,
            threat: c.signature.threat.toLowerCase(),
            category: c.signature.category,
        })),
        ...scanResults.localStorage.map(l => ({
            name: l.signature.description,
            detail: `localStorage: ${l.key} (${formatBytes(l.size)})`,
            threat: l.signature.threat.toLowerCase(),
            category: l.signature.category,
        })),
        ...scanResults.indexedDB.map(d => ({
            name: d.signature.description,
            detail: `IndexedDB: ${d.name}`,
            threat: d.signature.threat.toLowerCase(),
            category: d.signature.category,
        })),
    ];

    // Sort by severity
    const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    allFindings.sort((a, b) => (severityOrder[a.threat] || 3) - (severityOrder[b.threat] || 3));

    // Deduplicate by company name
    const seen = new Set();
    const deduped = allFindings.filter(f => {
        const key = f.name + f.detail;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });

    findingsCount.textContent = deduped.length;

    for (const finding of deduped) {
        const item = document.createElement('div');
        item.className = 'finding-item';
        item.innerHTML = `
      <div class="finding-dot ${finding.threat}"></div>
      <div class="finding-info">
        <div class="finding-name">${escapeHtml(finding.name)}</div>
        <div class="finding-detail">${escapeHtml(finding.detail)}</div>
      </div>
      <div class="finding-badge ${finding.threat}">${finding.threat.toUpperCase()}</div>
    `;
        findingsList.appendChild(item);
    }

    // If no findings
    if (deduped.length === 0) {
        findingsList.innerHTML = `
      <div style="text-align:center; padding: 24px; color: #22c55e; font-family: var(--mono); font-size: 12px;">
        ✅ No known tracker signatures detected on this page
      </div>
    `;
    }
}

// ─── BURN TRACKERS ───
async function burnTrackers() {
    cleanBtn.disabled = true;
    cleanBtn.innerHTML = '<span>🔥</span> BURNING...';

    let removed = 0;
    for (const cookie of scanResults.cookies) {
        try {
            const cleanDomain = cookie.domain.startsWith('.') ? cookie.domain.slice(1) : cookie.domain;
            // Try both https and http with proper URL format
            const urls = [`https://${cleanDomain}/`, `http://${cleanDomain}/`];
            for (const url of urls) {
                try {
                    await chrome.cookies.remove({ url: url, name: cookie.name });
                    removed++;
                    break;
                } catch (e) { }
            }
        } catch (e) {
            // Some cookies resist removal
        }
    }

    // Clean localStorage via content script
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.id) {
            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: burnLocalStorageInPage,
                args: [LOCALSTORAGE_SIGNATURES.map(s => s.key)],
            });
        }
    } catch (e) { }

    cleanBtn.innerHTML = `<span>✅</span> BURNED ${removed} COOKIES`;

    // Auto-rescan after 2 seconds to show updated results
    setTimeout(async () => {
        cleanBtn.innerHTML = '<span>🔥</span> BURN TRACKERS';
        cleanBtn.disabled = false;
        // Trigger rescan
        resultsSection.classList.add('hidden');
        await startScan();
    }, 2000);
}

function burnLocalStorageInPage(signatureKeys) {
    let removed = 0;
    try {
        const keysToRemove = [];
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            for (const sigKey of signatureKeys) {
                if (key.toLowerCase().includes(sigKey.toLowerCase())) {
                    keysToRemove.push(key);
                    break;
                }
            }
        }
        for (const key of keysToRemove) {
            localStorage.removeItem(key);
            removed++;
        }
    } catch (e) { }
    return removed;
}

// ─── EXPORT REPORT ───
function exportReport() {
    const score = scanResults.score;
    const timestamp = new Date().toLocaleString();

    let report = `VNR VIPER — THREAT SCAN REPORT\n`;
    report += `${'═'.repeat(50)}\n`;
    report += `Generated: ${timestamp}\n`;
    report += `Contamination Score: ${score}%\n`;
    report += `Total Findings: ${scanResults.totalThreats}\n\n`;

    report += `── SUMMARY ──\n`;
    report += `Tracker Cookies Found: ${scanResults.cookies.length}\n`;
    report += `Crypto PoW Residue: ${scanResults.cryptoDetected ? 'DETECTED ⚠' : 'Not detected'}\n`;
    report += `Session Replay: ${scanResults.replayDetected ? 'DETECTED ⚠' : 'Not detected'}\n`;
    report += `Ad Exchange Syncs: ${scanResults.adSyncDomains} services\n`;
    report += `IndexedDB Databases: ${scanResults.indexedDB.length}\n\n`;

    report += `── COOKIE FINDINGS ──\n`;
    for (const c of scanResults.cookies) {
        report += `[${c.signature.threat}] ${c.signature.company} — ${c.name} @ ${c.domain} (expires: ${c.expires})\n`;
    }

    report += `\n── LOCALSTORAGE FINDINGS ──\n`;
    for (const l of scanResults.localStorage) {
        report += `[${l.signature.threat}] ${l.signature.description} — ${l.key} (${formatBytes(l.size)})\n`;
    }

    report += `\n── INDEXEDDB FINDINGS ──\n`;
    for (const d of scanResults.indexedDB) {
        report += `[${d.signature.threat}] ${d.signature.description} — ${d.name}\n`;
    }

    report += `\n── TRACKED DOMAINS ──\n`;
    for (const d of scanResults.domains) {
        report += `• ${d}\n`;
    }

    report += `\n${'═'.repeat(50)}\n`;
    report += `Report generated by VNR VIPER v1.0.0\n`;
    report += `Voss Neural Research LLC — vossneuralresearch.com\n`;
    report += `Learn more: vossneuralresearch.com/suno-report\n`;

    // Download as text file
    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `VNR_VIPER_Scan_${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
}

// ─── UTILITIES ───
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

function updateStatus(text, color) {
    const dot = statusIndicator.querySelector('.status-dot');
    const label = statusIndicator.querySelector('.status-text');
    dot.style.background = color;
    label.style.color = color;
    label.textContent = text;
}
